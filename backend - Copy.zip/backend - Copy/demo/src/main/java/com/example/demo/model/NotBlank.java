package com.example.demo.model;

public @interface NotBlank {

}
